import React, { useEffect, useState } from 'react'


const  Navbar = () => {
    const [theme ,setTheme] = useState("light-theme")
  const changeColor = () =>{
    theme === "dark-theme" ? setTheme("light-theme"):setTheme("dark-theme")
}
  
  useEffect(() => {
     document.body.className = theme
    },[theme])
  

  return (
   <nav className='colored-nav'>
      <button className='icon-btn'onClick={changeColor}><i class="bi bi-brightness-high-fill" id="toggledark"></i></button>
       

    Expense manager
    
   </nav>
  )
}

export default Navbar
