export const saveTransaction = (transaction) =>{
    return transaction
};



export const deleteTransaction = (id) =>{
   return id
}
